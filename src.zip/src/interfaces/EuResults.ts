export interface EuResult {
    dim1: number;
    dim2: number;
    dim3: number;
    dim4: number;
    dim5: number;
    dim6: number;
    dimG: number;
}